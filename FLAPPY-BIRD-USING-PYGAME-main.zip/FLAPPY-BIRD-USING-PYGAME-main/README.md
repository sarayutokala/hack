# FLAPPY-BIRD-USING-PYGAME
 👉🏻 It is a simple Flappy Bird Game in Python using Pygame.
 
---

<p align="center"> <b> 👉🏻 Created Flappy Bird Game Using PyGame 👈🏻 <b> </p>
 
<p align="center"><a href='https://github.com/Amey-Thakur/FLAPPY-BIRD-USING-PYGAME', style='color: greenyellow;'> ✌🏻 Back To Repository ✌🏻</p>
